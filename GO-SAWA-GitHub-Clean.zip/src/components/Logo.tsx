import Link from 'next/link'
import Image from 'next/image'

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-3">
      <span className="relative block h-11 w-11 overflow-hidden rounded-xl bg-white shadow-md ring-1 ring-black/5">
        <Image src="/images/gosawa-logo.png" alt="GO SAWA globe logo" fill sizes="44px" className="object-cover object-top" priority />
      </span>
      <span>
        <b className={`block font-display text-lg font-extrabold leading-tight ${light ? 'text-white' : 'text-[#0b2e25]'}`}>GOSAWA</b>
        <small className={`block text-[10px] ${light ? 'text-[#93b2a9]' : 'text-[#68766f]'}`}>COMPANY LTD</small>
      </span>
    </Link>
  )
}

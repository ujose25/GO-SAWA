'use client'

import Link from 'next/link'
import { useActionState, useState } from 'react'
import {
  forgotPasswordAction,
  loginAction,
  registerAction,
  resetPasswordAction,
  type ActionState,
} from '@/app/(frontend)/actions'

const initialState: ActionState = { ok: false, message: '' }
const trades = ['Electrical Installation', 'Automotive Engineering', 'Hospitality & Catering', 'Building & Construction', 'ICT & Digital Services', 'Welding & Fabrication', 'Plumbing', 'Fashion & Design']

export function AuthForm({ mode, token, initialRole = 'student' }: { mode: 'login' | 'register' | 'forgot' | 'reset'; token?: string; initialRole?: 'student' | 'company' }) {
  const action = mode === 'login' ? loginAction : mode === 'register' ? registerAction : mode === 'forgot' ? forgotPasswordAction : resetPasswordAction
  const [state, formAction, pending] = useActionState(action, initialState)
  const [role, setRole] = useState(initialRole)

  return (
    <form action={formAction} className="mt-8 space-y-4">
      {mode === 'register' && (
        <>
          <div className="grid grid-cols-2 rounded-xl bg-[#eef3f1] p-1">
            {(['student', 'company'] as const).map((option) => (
              <button key={option} type="button" onClick={() => setRole(option)} className={`rounded-lg px-3 py-2.5 text-sm font-bold capitalize transition ${role === option ? 'bg-white text-[#103b30] shadow-sm' : 'text-[#77847e]'}`}>{option}</button>
            ))}
          </div>
          <input type="hidden" name="role" value={role} />
          <Field name="name" label={role === 'student' ? 'Full name' : 'Contact person'} placeholder={role === 'student' ? 'e.g. Amina Kamau' : 'Your full name'} error={state.errors?.name} />
          {role === 'student'
            ? <Field name="nationalId" label="National ID number" placeholder="Enter your ID number" error={state.errors?.nationalId} />
            : <Field name="companyName" label="Company name" placeholder="Registered company name" error={state.errors?.companyName} />}
          <label className="block text-sm font-bold text-[#405049]">Trade / Industry
            <select name="trade" required defaultValue="" className="mt-2 w-full rounded-xl border border-[#dce4e0] bg-[#fafcfb] px-4 py-3 text-sm font-normal outline-none focus:border-[#65a08b] focus:ring-4 focus:ring-[#dff0e9]">
              <option value="" disabled>Select your primary trade</option>
              {trades.map((trade) => <option key={trade}>{trade}</option>)}
            </select>
          </label>
          <Field name="location" label="Location" placeholder="Town or county" error={state.errors?.location} />
          <div className="grid grid-cols-[105px_1fr] gap-3">
            <label className="block text-sm font-bold text-[#405049]">Code
              <select name="countryCode" defaultValue="+254" className="mt-2 w-full rounded-xl border border-[#dce4e0] bg-[#fafcfb] px-3 py-3 text-sm font-normal outline-none"><option>+254</option><option>+255</option><option>+256</option><option>+250</option><option>+251</option><option>+27</option></select>
            </label>
            <Field name="phoneNumber" label="Phone number" placeholder="712 345 678" error={state.errors?.phoneNumber} />
          </div>
        </>
      )}

      {mode !== 'reset' && <Field name="email" type="email" label="Email address" placeholder="you@example.com" error={state.errors?.email} />}
      {(mode === 'login' || mode === 'register') && <Field name="password" type="password" label="Password" placeholder={mode === 'register' ? 'At least 8 characters' : 'Enter your password'} error={state.errors?.password} />}
      {mode === 'reset' && <><input type="hidden" name="token" value={token || ''} /><Field name="password" type="password" label="New password" placeholder="At least 8 characters" /></>}

      {state.message && <p className={`rounded-xl px-4 py-3 text-sm ${state.ok ? 'bg-[#e5f3ed] text-[#34745e]' : 'bg-[#fff0eb] text-[#a95138]'}`}>{state.message}</p>}

      <button disabled={pending} className="w-full rounded-xl bg-[#155143] px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-950/10 transition hover:bg-[#1d6654] disabled:opacity-60">
        {pending ? 'Please wait…' : mode === 'login' ? 'Sign in to GO SAWA' : mode === 'register' ? 'Create my account' : mode === 'forgot' ? 'Send reset instructions' : 'Update password'}
      </button>

      {mode === 'login' && <div className="flex justify-between text-sm"><Link className="font-bold text-[#1d6654]" href="/forgot-password">Forgot password?</Link><Link className="text-[#68766f]" href="/register">Create account</Link></div>}
      {mode === 'register' && <p className="text-center text-sm text-[#68766f]">Already registered? <Link className="font-bold text-[#1d6654]" href="/login">Sign in</Link></p>}
      {(mode === 'forgot' || mode === 'reset') && <p className="text-center text-sm"><Link className="font-bold text-[#1d6654]" href="/login">Back to sign in</Link></p>}
    </form>
  )
}

function Field({ label, error, ...props }: { label: string; error?: string; name: string; type?: string; placeholder?: string }) {
  return (
    <label className="block text-sm font-bold text-[#405049]">{label}
      <input required {...props} className="mt-2 w-full rounded-xl border border-[#dce4e0] bg-[#fafcfb] px-4 py-3 text-sm font-normal outline-none focus:border-[#65a08b] focus:ring-4 focus:ring-[#dff0e9]" />
      {error && <span className="mt-1 block text-xs font-medium text-[#a95138]">{error}</span>}
    </label>
  )
}

import { Logo } from './Logo'
import { AuthForm } from './AuthForm'

export function AuthPage({ mode, token, initialRole }: { mode: 'login' | 'register' | 'forgot' | 'reset'; token?: string; initialRole?: 'student' | 'company' }) {
  const copy = {
    login: ['Welcome back', 'Sign in to manage your GO SAWA journey.'],
    register: ['Create your account', 'Join the pathway between practical skills and industry.'],
    forgot: ['Reset your password', 'Enter your email and we’ll send secure reset instructions.'],
    reset: ['Choose a new password', 'Use a strong password you have not used before.'],
  }[mode]
  return (
    <main className="grid min-h-screen bg-[#f5f8f6] lg:grid-cols-[.82fr_1.18fr]">
      <section className="flex flex-col justify-between bg-[#0b2e25] p-8 text-white lg:p-12">
        <Logo light />
        <div className="my-16 max-w-md">
          <span className="text-xs font-bold uppercase tracking-[.16em] text-[#f0c171]">GO SAWA</span>
          <h2 className="mt-4 font-display text-4xl font-extrabold leading-tight tracking-[-.04em]">When skills and opportunity meet, everyone moves forward.</h2>
          <p className="mt-5 leading-7 text-[#a9beb8]">A secure bridge connecting TVET students, companies and programme administrators.</p>
        </div>
        <p className="text-xs text-[#78958c]">Designed by night_des technologies</p>
      </section>
      <section className="flex items-center justify-center p-5 py-12">
        <div className="w-full max-w-md rounded-2xl border border-[#e3e9e6] bg-white p-6 shadow-xl shadow-emerald-950/5 sm:p-9">
          <span className="text-xs font-bold uppercase tracking-[.16em] text-[#1d6654]">{mode === 'register' ? 'Get started' : 'Account access'}</span>
          <h1 className="mt-3 font-display text-3xl font-extrabold tracking-[-.04em] text-[#0b2e25]">{copy[0]}</h1>
          <p className="mt-2 text-sm leading-6 text-[#68766f]">{copy[1]}</p>
          <AuthForm mode={mode} token={token} initialRole={initialRole} />
        </div>
      </section>
    </main>
  )
}

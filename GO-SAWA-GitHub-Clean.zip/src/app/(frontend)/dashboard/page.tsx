import config from '@payload-config'
import { getPayload } from 'payload'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Logo } from '@/components/Logo'
import { appAuth } from '@/lib/app-auth'
import { logoutAction } from '../actions'

type OpportunityView = {
  id: string | number
  title: string
  trade: string
  location: string
  slots: number
  closingDate: string
  company?: { companyName?: string; name?: string } | string | number
  status: string
}

type MatchView = {
  id: string | number
  trade: string
  status: string
  company?: { companyName?: string; name?: string } | string | number
  student?: { name?: string } | string | number
}

export default async function DashboardPage() {
  const user = await appAuth.currentUser()
  if (!user) redirect('/login')

  const payload = await getPayload({ config })
  const isStudent = user.role === 'student'

  const [opportunities, applications, matches] = await Promise.all([
    payload.find({
      collection: 'opportunities',
      where: isStudent
        ? { and: [{ status: { equals: 'open' } }, { trade: { equals: user.trade } }] }
        : { company: { equals: user.id } },
      limit: 8,
      sort: '-createdAt',
      depth: 1,
      overrideAccess: false,
      user,
    }),
    payload.find({
      collection: 'applications',
      limit: 100,
      depth: 2,
      overrideAccess: false,
      user,
    }),
    payload.find({
      collection: 'matches',
      limit: 8,
      depth: 1,
      sort: '-createdAt',
      overrideAccess: false,
      user,
    }),
  ])

  const opportunityDocs = opportunities.docs as unknown as OpportunityView[]
  const matchDocs = matches.docs as unknown as MatchView[]
  const displayName = isStudent ? user.name : user.companyName || user.name
  const initials = String(displayName || 'GS').split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase()

  return (
    <main className="min-h-screen bg-[#f5f8f6] text-[#17231f]">
      <header className="border-b border-[#e3e9e6] bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-10">
          <Logo />
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block"><p className="text-sm font-bold">{displayName}</p><p className="text-xs capitalize text-[#68766f]">{user.role} account</p></div>
            <span className="grid h-10 w-10 place-items-center rounded-full bg-[#ddf2e9] text-xs font-extrabold text-[#155143]">{initials}</span>
            <form action={logoutAction}><button className="rounded-xl border border-[#dce4e0] bg-white px-3.5 py-2.5 text-xs font-bold text-[#405049]">Sign out</button></form>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-5 py-9 lg:px-10">
        <section className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <span className="text-xs font-bold uppercase tracking-[.16em] text-[#1d6654]">{isStudent ? 'Student workspace' : 'Company workspace'}</span>
            <h1 className="mt-2 font-display text-3xl font-extrabold tracking-[-.04em] text-[#0b2e25]">Welcome, {user.name}</h1>
            <p className="mt-2 text-sm text-[#68766f]">{isStudent ? `Opportunities matched to ${user.trade}` : 'Manage your opportunities and review candidate progress.'}</p>
          </div>
          <span className={`w-fit rounded-full px-3 py-1.5 text-xs font-bold capitalize ${user.profileStatus === 'verified' ? 'bg-[#e5f3ed] text-[#34745e]' : 'bg-[#fbf0df] text-[#996726]'}`}>{user.profileStatus || 'pending'} profile</span>
        </section>

        <section className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            [isStudent ? 'Matching opportunities' : 'Your opportunities', opportunities.totalDocs],
            ['Applications', applications.totalDocs],
            ['Active matches', matches.totalDocs],
          ].map(([label, value], index) => (
            <article key={String(label)} className="rounded-2xl border border-[#e3e9e6] bg-white p-6 shadow-sm">
              <span className={`mb-5 grid h-10 w-10 place-items-center rounded-xl text-sm font-black ${index === 0 ? 'bg-[#e5f3ed] text-[#34745e]' : index === 1 ? 'bg-[#e8f2f7] text-[#426f8e]' : 'bg-[#fbf0df] text-[#996726]'}`}>0{index + 1}</span>
              <p className="text-sm text-[#68766f]">{label}</p><strong className="mt-1 block font-display text-3xl">{value}</strong>
            </article>
          ))}
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[1.6fr_.8fr]">
          <div className="overflow-hidden rounded-2xl border border-[#e3e9e6] bg-white">
            <div className="border-b border-[#edf1ef] p-5"><h2 className="font-display text-lg font-extrabold">{isStudent ? 'Opportunities for your trade' : 'Your internship opportunities'}</h2><p className="mt-1 text-xs text-[#68766f]">Live data from the GO SAWA placement system</p></div>
            <div className="divide-y divide-[#edf1ef]">
              {opportunityDocs.map((opportunity) => {
                const company = typeof opportunity.company === 'object' ? opportunity.company?.companyName || opportunity.company?.name : 'Verified company'
                return (
                  <article key={opportunity.id} className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#e5f3ed] text-sm font-black text-[#34745e]">GS</span>
                    <div className="min-w-0 flex-1"><h3 className="font-bold">{opportunity.title}</h3><p className="mt-1 text-xs text-[#68766f]">{company} · {opportunity.location}</p><span className="mt-2 inline-block rounded-full bg-[#f5f8f6] px-2.5 py-1 text-[11px] font-bold text-[#405049]">{opportunity.trade}</span></div>
                    <div className="text-left sm:text-right"><p className="text-xs font-bold text-[#1d6654]">{opportunity.slots} slot{opportunity.slots === 1 ? '' : 's'}</p><p className="mt-1 text-[11px] text-[#89938f]">Closes {new Date(opportunity.closingDate).toLocaleDateString()}</p></div>
                  </article>
                )
              })}
              {opportunityDocs.length === 0 && (
                <div className="px-5 py-14 text-center"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[#eef3f1] text-lg font-black text-[#678078]">G</span><h3 className="mt-4 font-bold">Nothing here yet</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#68766f]">{isStudent ? 'New verified opportunities matching your trade will appear here.' : 'Create opportunities in the GO SAWA admin workflow after your company profile is verified.'}</p></div>
              )}
            </div>
          </div>

          <aside className="space-y-6">
            <div className="rounded-2xl bg-[#0b2e25] p-6 text-white">
              <span className="text-xs font-bold uppercase tracking-[.14em] text-[#f0c171]">Profile strength</span>
              <div className="mt-5 flex items-end justify-between"><strong className="font-display text-4xl">{user.readiness || 25}%</strong><span className="text-xs text-[#a9beb8]">{user.profileStatus === 'verified' ? 'Verified' : 'Under review'}</span></div>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-[#e7ad4d]" style={{ width: `${user.readiness || 25}%` }} /></div>
              <p className="mt-4 text-xs leading-5 text-[#a9beb8]">Keep your contact details and trade profile accurate. Administrators use them when checking placement eligibility.</p>
            </div>
            <div className="rounded-2xl border border-[#e3e9e6] bg-white p-5">
              <h2 className="font-bold">Recent matches</h2>
              <div className="mt-4 space-y-3">
                {matchDocs.map((match) => {
                  const other = isStudent
                    ? (typeof match.company === 'object' ? match.company?.companyName || match.company?.name : 'Company')
                    : (typeof match.student === 'object' ? match.student?.name : 'Student')
                  return <div key={match.id} className="rounded-xl bg-[#f7f9f8] p-3"><p className="text-sm font-bold">{other}</p><p className="mt-1 text-xs text-[#68766f]">{match.trade}</p><span className="mt-2 inline-block text-[10px] font-bold uppercase text-[#1d6654]">{match.status}</span></div>
                })}
                {matchDocs.length === 0 && <p className="rounded-xl bg-[#f7f9f8] p-4 text-xs leading-5 text-[#68766f]">No placement match has been created yet. The programme admin manages verified connections.</p>}
              </div>
            </div>
          </aside>
        </section>

        <div className="mt-8 flex flex-col gap-2 border-t border-[#e3e9e6] pt-6 text-xs text-[#82908a] sm:flex-row sm:justify-between">
          <p>GO SAWA keeps student and company accounts separate from CMS administration.</p>
          <p>Designed by <b className="text-[#1d6654]">night_des technologies</b></p>
        </div>
      </div>
    </main>
  )
}

import Link from 'next/link'
import Image from 'next/image'
import { Logo } from '@/components/Logo'

const steps = [
  ['01', 'Create your profile', 'Students register with their national ID and trade. Companies define the skills they need.'],
  ['02', 'Get matched by trade', 'GO SAWA surfaces eligible students and opportunities while administrators verify every connection.'],
  ['03', 'Start the placement', 'Track applications, interviews, acceptance and placement progress in one secure system.'],
]

const ecosystem = [
  {
    image: '/images/employer-partnership.jpg',
    label: 'Employer networks',
    title: 'Companies ready to grow talent',
    copy: 'Verified employers publish structured placements and review candidates whose training fits the work.',
    alt: 'Business professionals collaborating around a table',
  },
  {
    image: '/images/electrical-work.jpg',
    label: 'Technical industry',
    title: 'Skilled trades and technicians',
    copy: 'Electrical, automotive, ICT and fabrication partners connect with students trained for practical environments.',
    alt: 'Electrician working safely on an installation',
  },
  {
    image: '/images/hospitality-training.jpg',
    label: 'Hospitality partners',
    title: 'Service and culinary careers',
    copy: 'Hotels, restaurants and training associations can identify work-ready hospitality talent by trade.',
    alt: 'Professional chef preparing food in a kitchen',
  },
  {
    image: '/images/construction-team.jpg',
    label: 'Industry associations',
    title: 'Safer routes into construction',
    copy: 'Associations and contractors help validate standards, workplace readiness and responsible placements.',
    alt: 'Construction professionals standing together',
  },
]

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#f5f8f6] text-[#17231f]">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-10">
        <Logo />
        <div className="flex items-center gap-2">
          <Link className="hidden rounded-xl px-4 py-2.5 text-sm font-bold text-[#155143] sm:block" href="/login">Sign in</Link>
          <Link className="rounded-xl bg-[#155143] px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-950/10" href="/register">Join GO SAWA</Link>
        </div>
      </nav>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-20 pt-12 lg:grid-cols-[1.05fr_.95fr] lg:px-10 lg:pb-28 lg:pt-20">
        <div>
          <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#d7e7e1] bg-white px-3 py-1.5 text-xs font-bold uppercase tracking-[.14em] text-[#1d6654]">
            <i className="h-2 w-2 rounded-full bg-[#e7ad4d]" /> Skills meet opportunity
          </span>
          <h1 className="max-w-3xl font-display text-5xl font-extrabold leading-[1.02] tracking-[-.055em] text-[#0b2e25] md:text-7xl">
            Your trade can take you <span className="text-[#1d6654]">somewhere.</span>
          </h1>
          <p className="mt-7 max-w-xl text-lg leading-8 text-[#68766f]">
            GO SAWA connects TVET students with verified companies for internships that match their skills, location and career direction.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link className="rounded-xl bg-[#155143] px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-950/15" href="/register?role=student">I’m a student</Link>
            <Link className="rounded-xl border border-[#cadbd5] bg-white px-6 py-3.5 text-sm font-bold text-[#103b30]" href="/register?role=company">I represent a company</Link>
          </div>
          <div className="mt-10 flex flex-wrap gap-7 text-sm text-[#68766f]">
            <span><b className="block text-xl text-[#17231f]">Trade-first</b> matching logic</span>
            <span><b className="block text-xl text-[#17231f]">Admin</b> verified placements</span>
            <span><b className="block text-xl text-[#17231f]">Secure</b> account access</span>
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-5 -z-0 rotate-2 rounded-[2.5rem] bg-[#e7ad4d]" />
          <div className="relative overflow-hidden rounded-[2rem] bg-[#0b2e25] p-6 text-white shadow-2xl md:p-9">
            <div className="relative -mx-6 -mt-6 mb-7 h-52 overflow-hidden md:-mx-9 md:-mt-9">
              <Image src="/images/employer-partnership.jpg" alt="GO SAWA employer partnership discussion" fill sizes="(max-width: 1024px) 100vw, 45vw" className="object-cover" priority />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b2e25] via-[#0b2e25]/20 to-transparent" />
              <span className="absolute bottom-4 left-6 rounded-full border border-white/20 bg-[#0b2e25]/70 px-3 py-1.5 text-[11px] font-bold backdrop-blur">Companies · Associations · TVET institutions</span>
            </div>
            <div className="mb-10 flex items-center justify-between">
              <div><p className="text-xs uppercase tracking-[.16em] text-[#93b2a9]">Matching snapshot</p><h2 className="mt-2 text-2xl font-bold">Right fit. Real progress.</h2></div>
              <span className="relative h-12 w-12 overflow-hidden rounded-2xl bg-white"><Image src="/images/gosawa-logo.png" alt="" fill sizes="48px" className="object-cover object-top" /></span>
            </div>
            <div className="space-y-3">
              {[
                ['AK', 'Amina Kamau', 'Electrical Installation', '92% fit'],
                ['DO', 'David Ochieng', 'Automotive Engineering', '88% fit'],
                ['FN', 'Faith Njeri', 'Hospitality & Catering', '86% fit'],
              ].map(([initials, name, trade, fit], index) => (
                <article key={name} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[.07] p-4">
                  <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-full text-xs font-bold ${index === 0 ? 'bg-[#dff1e9] text-[#286d57]' : index === 1 ? 'bg-[#e4eef5] text-[#527994]' : 'bg-[#f6e9d8] text-[#9b672d]'}`}>{initials}</span>
                  <div className="min-w-0 flex-1"><h3 className="font-bold">{name}</h3><p className="truncate text-xs text-[#a9beb8]">{trade}</p></div>
                  <span className="rounded-full bg-[#e7ad4d]/15 px-2.5 py-1 text-xs font-bold text-[#f0c171]">{fit}</span>
                </article>
              ))}
            </div>
            <div className="mt-6 grid grid-cols-3 gap-3">
              {['Verified profiles', 'Trade aligned', 'Admin approved'].map((item) => <div key={item} className="rounded-xl bg-white/[.05] p-3 text-center text-[11px] leading-4 text-[#a9beb8]">{item}</div>)}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-10">
          <span className="text-xs font-bold uppercase tracking-[.16em] text-[#1d6654]">How it works</span>
          <h2 className="mt-3 max-w-xl font-display text-3xl font-extrabold tracking-[-.04em] text-[#0b2e25] md:text-4xl">One clear pathway from training to industry.</h2>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {steps.map(([number, title, copy]) => (
              <article key={number} className="rounded-2xl border border-[#e3e9e6] bg-[#fbfcfb] p-7">
                <span className="text-sm font-extrabold text-[#d69434]">{number}</span>
                <h3 className="mt-8 text-lg font-bold text-[#0b2e25]">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-[#68766f]">{copy}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#0b2e25] py-20 text-white">
        <div className="mx-auto max-w-7xl px-5 lg:px-10">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <span className="text-xs font-bold uppercase tracking-[.16em] text-[#f0c171]">The GO SAWA ecosystem</span>
              <h2 className="mt-3 max-w-2xl font-display text-3xl font-extrabold tracking-[-.04em] md:text-4xl">Built for companies, associations and the people they employ.</h2>
            </div>
            <p className="max-w-md text-sm leading-6 text-[#a9beb8]">One coordinated platform helps industry partners find relevant skills while programme administrators protect placement quality.</p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {ecosystem.map((item) => (
              <article key={item.title} className="group overflow-hidden rounded-2xl border border-white/10 bg-white/[.06]">
                <div className="relative h-48 overflow-hidden">
                  <Image src={item.image} alt={item.alt} fill sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw" className="object-cover transition duration-500 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b2e25]/75 to-transparent" />
                  <span className="absolute bottom-3 left-4 text-[10px] font-extrabold uppercase tracking-[.13em] text-[#f0c171]">{item.label}</span>
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-extrabold">{item.title}</h3>
                  <p className="mt-3 text-xs leading-5 text-[#a9beb8]">{item.copy}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            {['TVET institutions', 'Private employers', 'Trade associations', 'Training providers', 'Programme administrators'].map((partner) => (
              <span key={partner} className="rounded-full border border-white/10 bg-white/[.05] px-4 py-2 text-xs font-bold text-[#c4d5d0]">{partner}</span>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-[#0b2e25] px-5 py-8 text-sm text-[#a9beb8]">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between lg:px-5">
          <p>© 2025 GO SAWA. Building pathways to meaningful work.</p>
          <p>Designed by <b className="text-[#f0c171]">night_des technologies</b></p>
        </div>
      </footer>
    </main>
  )
}

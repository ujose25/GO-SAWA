'use server'

import config from '@payload-config'
import { getPayload } from 'payload'
import { redirect } from 'next/navigation'
import { appAuth } from '@/lib/app-auth'

export type ActionState = {
  ok: boolean
  message: string
  errors?: Record<string, string>
}

const text = (formData: FormData, key: string) => String(formData.get(key) || '').trim()

export async function registerAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const role = text(formData, 'role')
  const email = text(formData, 'email').toLowerCase()
  const password = text(formData, 'password')
  const name = text(formData, 'name')
  const trade = text(formData, 'trade')
  const location = text(formData, 'location')
  const countryCode = text(formData, 'countryCode')
  const phoneNumber = text(formData, 'phoneNumber')
  const nationalId = text(formData, 'nationalId')
  const companyName = text(formData, 'companyName')

  const errors: Record<string, string> = {}
  if (!['student', 'company'].includes(role)) errors.role = 'Choose a valid account type.'
  if (!email.includes('@')) errors.email = 'Enter a valid email address.'
  if (password.length < 8) errors.password = 'Use at least 8 characters.'
  if (!name) errors.name = 'Your name is required.'
  if (!trade) errors.trade = 'Select your trade.'
  if (!location) errors.location = 'Location is required.'
  if (!phoneNumber) errors.phoneNumber = 'Phone number is required.'
  if (role === 'student' && !nationalId) errors.nationalId = 'National ID is required.'
  if (role === 'company' && !companyName) errors.companyName = 'Company name is required.'
  if (Object.keys(errors).length) return { ok: false, message: 'Check the highlighted details.', errors }

  try {
    const payload = await getPayload({ config })
    await payload.create({
      collection: 'users',
      data: {
        role: role as 'student' | 'company',
        email,
        password,
        name,
        trade: trade as 'Electrical Installation' | 'Automotive Engineering' | 'Hospitality & Catering' | 'Building & Construction' | 'ICT & Digital Services' | 'Welding & Fabrication' | 'Plumbing' | 'Fashion & Design',
        location,
        countryCode: countryCode as '+254' | '+255' | '+256' | '+250' | '+251' | '+27',
        phoneNumber,
        nationalId: role === 'student' ? nationalId : undefined,
        companyName: role === 'company' ? companyName : undefined,
      },
      overrideAccess: false,
    })
    await appAuth.login(email, password)
  } catch (error) {
    const message = error instanceof Error && error.message.toLowerCase().includes('email')
      ? 'An account with this email may already exist.'
      : 'We could not create your account. Please check your details.'
    return { ok: false, message }
  }
  redirect('/dashboard')
}

export async function loginAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const email = text(formData, 'email').toLowerCase()
  const password = text(formData, 'password')
  if (!email || !password) return { ok: false, message: 'Enter your email and password.' }
  try {
    await appAuth.login(email, password)
  } catch {
    return { ok: false, message: 'Email or password is incorrect.' }
  }
  redirect('/dashboard')
}

export async function logoutAction() {
  await appAuth.logout()
  redirect('/')
}

export async function forgotPasswordAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const email = text(formData, 'email').toLowerCase()
  const generic = 'If an account exists, reset instructions will be sent to that email.'
  if (!email.includes('@')) return { ok: false, message: 'Enter a valid email address.' }
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM_ADDRESS) {
    return { ok: true, message: `${generic} Email delivery is awaiting provider setup.` }
  }
  try {
    const payload = await getPayload({ config })
    await payload.forgotPassword({
      collection: 'users',
      data: { email },
      overrideAccess: true,
    })
  } catch {
    // Keep the response generic so account existence is never disclosed.
  }
  return { ok: true, message: generic }
}

export async function resetPasswordAction(_: ActionState, formData: FormData): Promise<ActionState> {
  const token = text(formData, 'token')
  const password = text(formData, 'password')
  if (!token) return { ok: false, message: 'This reset link is invalid or expired.' }
  if (password.length < 8) return { ok: false, message: 'Use at least 8 characters.' }
  try {
    const payload = await getPayload({ config })
    await payload.resetPassword({
      collection: 'users',
      data: { password, token },
      overrideAccess: true,
    })
  } catch {
    return { ok: false, message: 'This reset link is invalid or expired.' }
  }
  return { ok: true, message: 'Password updated. You can now sign in.' }
}

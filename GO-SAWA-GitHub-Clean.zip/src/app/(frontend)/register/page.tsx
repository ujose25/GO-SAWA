import { AuthPage } from '@/components/AuthPage'

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ role?: string }> }) {
  const { role } = await searchParams
  return <AuthPage mode="register" initialRole={role === 'company' ? 'company' : 'student'} />
}

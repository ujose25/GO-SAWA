import { AuthPage } from '@/components/AuthPage'

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams
  return <AuthPage mode="reset" token={token} />
}

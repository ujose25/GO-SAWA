import { redirect } from 'next/navigation'
import { AuthPage } from '@/components/AuthPage'
import { appAuth } from '@/lib/app-auth'

export default async function LoginPage() {
  if (await appAuth.currentUser()) redirect('/dashboard')
  return <AuthPage mode="login" />
}

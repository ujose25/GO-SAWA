import config from '@payload-config'
import { getPayload } from 'payload'
import { cookies } from 'next/headers'

const COOKIE_NAME = 'app-session'

export function createAppAuth(collection: 'users') {
  return {
    async currentUser() {
      const token = (await cookies()).get(COOKIE_NAME)?.value
      if (!token) return null

      const payload = await getPayload({ config })
      const authHeaders = new Headers({ Authorization: `JWT ${token}` })
      const { user } = await payload.auth({ headers: authHeaders })
      if (!user || user.collection !== collection) return null
      return user
    },
    async login(email: string, password: string) {
      const payload = await getPayload({ config })
      const result = await payload.login({
        collection,
        data: { email, password },
        overrideAccess: false,
      })
      if (!result.token) throw new Error('Unable to create a secure session.')
      const cookieStore = await cookies()
      cookieStore.set(COOKIE_NAME, result.token, {
        httpOnly: true,
        maxAge: 2 * 60 * 60,
        path: '/',
        sameSite: 'lax',
        secure: process.env.NODE_ENV === 'production',
      })
      return result.user
    },
    async logout() {
      ;(await cookies()).delete(COOKIE_NAME)
    },
  }
}

export const appAuth = createAppAuth('users')

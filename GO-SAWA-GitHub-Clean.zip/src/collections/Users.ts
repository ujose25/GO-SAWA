import type { Access, CollectionBeforeValidateHook, CollectionConfig } from 'payload'

const isAdmin = (user: unknown): user is { collection: 'admins' } =>
  Boolean(user && typeof user === 'object' && 'collection' in user && user.collection === 'admins')

const ownProfileOrAdmin: Access = ({ req }) => {
  if (isAdmin(req.user)) return true
  if (req.user?.collection === 'users') return { id: { equals: req.user.id } }
  return false
}

const validateRoleProfile: CollectionBeforeValidateHook = ({ data }) => {
  if (!data) return data

  if (data.role === 'student' && !data.nationalId) {
    throw new Error('National ID is required for student accounts.')
  }
  if (data.role === 'company' && !data.companyName) {
    throw new Error('Company name is required for company accounts.')
  }

  return data
}

export const Users: CollectionConfig = {
  slug: 'users',
  access: {
    admin: () => false,
    create: () => true,
    delete: ({ req }) => isAdmin(req.user),
    read: ownProfileOrAdmin,
    update: ownProfileOrAdmin,
  },
  admin: {
    group: 'GO SAWA',
    useAsTitle: 'name',
  },
  auth: {
    forgotPassword: {
      expiration: 60 * 60 * 1000,
      minRequestInterval: 30_000,
      generateEmailSubject: () => 'Reset your GO SAWA password',
      generateEmailHTML: (args) => {
        const token = args?.token
        const base = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'
        return `<p>You requested a password reset for GO SAWA.</p><p><a href="${base}/reset-password?token=${token}">Reset your password</a></p><p>This link expires in one hour.</p>`
      },
    },
    maxLoginAttempts: 5,
    lockTime: 15 * 60 * 1000,
    tokenExpiration: 2 * 60 * 60,
    useSessions: true,
  },
  hooks: {
    beforeValidate: [validateRoleProfile],
  },
  fields: [
    {
      name: 'role',
      type: 'select',
      required: true,
      options: [
        { label: 'Student', value: 'student' },
        { label: 'Company', value: 'company' },
      ],
    },
    { name: 'name', type: 'text', required: true },
    {
      name: 'nationalId',
      type: 'text',
      index: true,
      admin: { condition: (_, siblingData) => siblingData?.role === 'student' },
    },
    {
      name: 'companyName',
      type: 'text',
      index: true,
      admin: { condition: (_, siblingData) => siblingData?.role === 'company' },
    },
    {
      name: 'registrationNumber',
      type: 'text',
      admin: { condition: (_, siblingData) => siblingData?.role === 'company' },
    },
    {
      name: 'trade',
      type: 'select',
      required: true,
      index: true,
      options: [
        'Electrical Installation',
        'Automotive Engineering',
        'Hospitality & Catering',
        'Building & Construction',
        'ICT & Digital Services',
        'Welding & Fabrication',
        'Plumbing',
        'Fashion & Design',
      ],
    },
    { name: 'location', type: 'text', required: true },
    {
      type: 'row',
      fields: [
        {
          name: 'countryCode',
          type: 'select',
          required: true,
          defaultValue: '+254',
          options: ['+254', '+255', '+256', '+250', '+251', '+27'],
        },
        { name: 'phoneNumber', type: 'text', required: true },
      ],
    },
    {
      name: 'profileStatus',
      type: 'select',
      defaultValue: 'pending',
      access: {
        create: ({ req }) => isAdmin(req.user),
        update: ({ req }) => isAdmin(req.user),
      },
      options: [
        { label: 'Pending review', value: 'pending' },
        { label: 'Verified', value: 'verified' },
        { label: 'Suspended', value: 'suspended' },
      ],
    },
    {
      name: 'readiness',
      type: 'number',
      defaultValue: 25,
      min: 0,
      max: 100,
      access: {
        create: ({ req }) => isAdmin(req.user),
        update: ({ req }) => isAdmin(req.user),
      },
      admin: { condition: (_, siblingData) => siblingData?.role === 'student' },
    },
  ],
  timestamps: true,
  versions: false,
}

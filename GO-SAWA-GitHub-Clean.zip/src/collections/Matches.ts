import type { Access, CollectionBeforeChangeHook, CollectionConfig, Where } from 'payload'

const isAdmin = (user: { collection?: string } | null | undefined) => user?.collection === 'admins'

const participantRead: Access = ({ req }) => {
  if (isAdmin(req.user)) return true
  if (req.user?.collection !== 'users') return false
  if (req.user.role === 'student') return { student: { equals: req.user.id } } as Where
  if (req.user.role === 'company') return { company: { equals: req.user.id } } as Where
  return false
}

const validateMatch: CollectionBeforeChangeHook = async ({ data, operation, originalDoc, req }) => {
  const studentId = typeof data.student === 'object' ? data.student?.id : data.student || originalDoc?.student
  const companyId = typeof data.company === 'object' ? data.company?.id : data.company || originalDoc?.company
  if (!studentId || !companyId) return data

  const [student, company] = await Promise.all([
    req.payload.findByID({ collection: 'users', id: studentId, depth: 0, overrideAccess: true }),
    req.payload.findByID({ collection: 'users', id: companyId, depth: 0, overrideAccess: true }),
  ])

  if (student.role !== 'student') throw new Error('The selected student account is invalid.')
  if (company.role !== 'company') throw new Error('The selected company account is invalid.')
  if (student.trade !== company.trade) {
    throw new Error('Student and company trades must match before a placement can be created.')
  }

  if (operation === 'create') return { ...data, trade: student.trade }
  return data
}

export const Matches: CollectionConfig = {
  slug: 'matches',
  access: {
    create: ({ req }) => isAdmin(req.user),
    delete: ({ req }) => isAdmin(req.user),
    read: participantRead,
    update: ({ req }) => isAdmin(req.user),
  },
  admin: { group: 'GO SAWA', useAsTitle: 'id' },
  hooks: { beforeChange: [validateMatch] },
  fields: [
    { name: 'student', type: 'relationship', relationTo: 'users', required: true, index: true },
    { name: 'company', type: 'relationship', relationTo: 'users', required: true, index: true },
    { name: 'opportunity', type: 'relationship', relationTo: 'opportunities' },
    { name: 'application', type: 'relationship', relationTo: 'applications' },
    { name: 'trade', type: 'text', required: true, index: true },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'proposed',
      options: ['proposed', 'company-review', 'interview', 'accepted', 'placed', 'declined', 'completed'],
    },
    { name: 'startDate', type: 'date' },
    { name: 'endDate', type: 'date' },
    { name: 'adminNotes', type: 'textarea' },
  ],
  timestamps: true,
}

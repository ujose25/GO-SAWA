import type { Access, CollectionBeforeChangeHook, CollectionConfig, Where } from 'payload'

const isAdmin = (user: { collection?: string } | null | undefined) => user?.collection === 'admins'
const isStudent = (user: { collection?: string; role?: string } | null | undefined) =>
  user?.collection === 'users' && user.role === 'student'

const participantRead: Access = ({ req }) => {
  if (isAdmin(req.user)) return true
  if (req.user?.collection !== 'users') return false
  if (req.user.role === 'student') return { student: { equals: req.user.id } } as Where
  if (req.user.role === 'company') return { 'opportunity.company': { equals: req.user.id } } as Where
  return false
}

const enforceEligibility: CollectionBeforeChangeHook = async ({ data, operation, req }) => {
  if (operation !== 'create') return data
  const user = req.user
  if (!user || user.collection !== 'users' || user.role !== 'student') {
    throw new Error('Only student accounts can apply for opportunities.')
  }

  const opportunityId =
    typeof data.opportunity === 'object' ? data.opportunity?.id : data.opportunity
  if (!opportunityId) throw new Error('An opportunity is required.')

  const opportunity = await req.payload.findByID({
    collection: 'opportunities',
    id: opportunityId,
    depth: 0,
    overrideAccess: true,
  })

  if (opportunity.status !== 'open') throw new Error('This opportunity is not open.')
  if (opportunity.trade !== user.trade) {
    throw new Error('Your registered trade does not match this opportunity.')
  }

  const duplicate = await req.payload.find({
    collection: 'applications',
    where: {
      and: [
        { student: { equals: user.id } },
        { opportunity: { equals: opportunityId } },
      ],
    },
    limit: 1,
    overrideAccess: true,
  })
  if (duplicate.totalDocs > 0) throw new Error('You have already applied for this opportunity.')

  return { ...data, student: user.id, status: 'submitted' }
}

export const Applications: CollectionConfig = {
  slug: 'applications',
  access: {
    create: ({ req }) => isStudent(req.user),
    delete: ({ req }) => isAdmin(req.user),
    read: participantRead,
    update: ({ req }) => isAdmin(req.user),
  },
  admin: { group: 'GO SAWA', useAsTitle: 'id' },
  hooks: { beforeChange: [enforceEligibility] },
  fields: [
    { name: 'student', type: 'relationship', relationTo: 'users', required: true, index: true },
    {
      name: 'opportunity',
      type: 'relationship',
      relationTo: 'opportunities',
      required: true,
      index: true,
    },
    { name: 'coverNote', type: 'textarea', maxLength: 1500 },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'submitted',
      access: {
        create: ({ req }) => isAdmin(req.user),
        update: ({ req }) => isAdmin(req.user),
      },
      options: ['submitted', 'reviewing', 'shortlisted', 'interview', 'accepted', 'declined'],
    },
    { name: 'adminNotes', type: 'textarea', access: { read: ({ req }) => isAdmin(req.user), update: ({ req }) => isAdmin(req.user) } },
  ],
  timestamps: true,
}

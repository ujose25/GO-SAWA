import type { Access, CollectionBeforeChangeHook, CollectionConfig, Where } from 'payload'

const isAdmin = (user: { collection?: string } | null | undefined) => user?.collection === 'admins'
const isCompany = (user: { collection?: string; role?: string } | null | undefined) =>
  user?.collection === 'users' && user.role === 'company'

const companyOwned: Access = ({ req }) => {
  const user = req.user
  if (isAdmin(user)) return true
  if (user?.collection === 'users' && user.role === 'company') return { company: { equals: user.id } }
  return false
}

const setCompany: CollectionBeforeChangeHook = ({ data, operation, req }) => {
  const user = req.user
  if (operation === 'create' && user?.collection === 'users' && user.role === 'company') {
    return { ...data, company: user.id }
  }
  return data
}

export const Opportunities: CollectionConfig = {
  slug: 'opportunities',
  access: {
    create: ({ req }) => isAdmin(req.user) || isCompany(req.user),
    delete: companyOwned,
    read: ({ req }) => {
      const user = req.user
      if (isAdmin(user)) return true
      if (user?.collection === 'users' && user.role === 'company') {
        return { or: [{ company: { equals: user.id } }, { status: { equals: 'open' } }] } as Where
      }
      return { status: { equals: 'open' } } as Where
    },
    update: companyOwned,
  },
  admin: { group: 'GO SAWA', useAsTitle: 'title' },
  hooks: { beforeChange: [setCompany] },
  fields: [
    { name: 'title', type: 'text', required: true },
    { name: 'company', type: 'relationship', relationTo: 'users', required: true, index: true },
    {
      name: 'trade',
      type: 'select',
      required: true,
      index: true,
      options: [
        'Electrical Installation',
        'Automotive Engineering',
        'Hospitality & Catering',
        'Building & Construction',
        'ICT & Digital Services',
        'Welding & Fabrication',
        'Plumbing',
        'Fashion & Design',
      ],
    },
    { name: 'location', type: 'text', required: true },
    { name: 'slots', type: 'number', required: true, min: 1, defaultValue: 1 },
    { name: 'description', type: 'textarea', required: true },
    { name: 'requirements', type: 'textarea' },
    { name: 'closingDate', type: 'date', required: true },
    {
      name: 'status',
      type: 'select',
      defaultValue: 'pending',
      access: {
        create: ({ req }) => isAdmin(req.user),
        update: ({ req }) => isAdmin(req.user),
      },
      options: ['pending', 'open', 'closed', 'filled'],
    },
  ],
  timestamps: true,
}
